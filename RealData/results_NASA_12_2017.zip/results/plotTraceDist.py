import matplotlib.pyplot as plt
import sys

#plot the trace distribution
ifile = open(sys.argv[1],"r")
lines = ifile.readlines()
ifile.close()
lines = [line.strip() for line in lines]

hist = dict() #trace string -> count
for line in lines:
	trace = line.split(",")[2]
	if trace in hist.keys():
		hist[trace] += 1
	else:
		hist[trace] = 1

items = [(key,hist[key]) for key in hist.keys()]
items.sort(key=lambda k: k[1], reverse=True)

xs = [i for i in range(len(items))]
ys = [tup[1] for tup in items]

plt.plot(xs,ys)
plt.show()
