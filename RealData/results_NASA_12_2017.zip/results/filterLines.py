ifile = open("testTraces.log","r")
lines = [line.strip() for line in ifile.readlines()]
ofile = open("testTracesCompressed.log","w+")

for line in lines:
	tokens = line.split(",")
	sutured = tokens[0]+","+tokens[1]+","
	for c in tokens[2]:
		if sutured[-1] != c:
			sutured += c
	print(sutured)
	ofile.write(sutured+"\n")
	
ifile.close()
ofile.close()

